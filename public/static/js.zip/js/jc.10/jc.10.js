// 此 插件需要引入jquery,md5.js
var jc = {
    api: 'http://www.qq.com/',
    init: function() {
        _this = this;
    },
    //表单提交
    submit: function(obj) {
        var form=$(obj).closest('form');
        $.ajax({
            type: 'POST',
            url:  _this.api+form.attr('action'),
            data:  form.serialize(),
            dataType: "JSON",
            success: function(result) {
                    if(result.status==0){
                        if(result.message!=''){
                            _this.alert(result.status,result.message);
                        }
                        if(result.data!=''){
                            window.location.href=result.data;
                        }
                    }else if( result.status==1){
                        _this.alert(result.status,result.message);
                    }
            }
        });
    } ,
    //搜索
    search: function(obj) {
        var form=$(obj).closest('form');
        form.submit();
    },
    //提示
    alert: function(status,message) {
            boxMsg(status,message);
    }
}