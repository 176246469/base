$(document).ready(function() {
var message=new jBox('Modal', {});

/*基于JBox消息提示框*/
function boxMsg(status,content){
    //成功
    if(status==0){
       var title='<span class="success">提示信息</span>';
    }else{
         var title='<span class="error">提示信息</span>'; 
    }
       message=new jBox('Modal', {
        height: 120,
        width: 300,
          title: title,
          content: '<div style="line-height: 30px; font-size:16px;text-align:center;">'+content+'</div>'
        });
       message.open();
}
/*基于JBox确认提示*/
function boxConfirm(content,e){
  message2=new jBox('Confirm', {
    content: content,
    cancelButton: '取消',
    confirmButton: '确定',
    confirm: e 
  });
  return  message2.open();
}
status
//
  jc.init();
//绑定表单提交

$('.change-status').click(function(event) {
      var targe-url=$(this).attr('targe-url');
      var targe-tag=$(this).attr('targe-tag');
      var targe-id=$(this).attr('targe-id');
      var targe-status=$(this).attr('targe-status');
      boxConfirm('确定要'+targe-tag+'?',function(){
          window.location.href=targe-url+'?id='+targe-id+'&targe-status='+targe-status;
      });
});

$('#submit').click(function(event) {
   jc.submit($(this));
});

//绑定搜索
$('#sreach').click(function(event) {
    jc.sreach$(this);
});
});